^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package abb_resources
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.1 (2017-03-27)
------------------
* Add abb_resources package from ros-industrial/abb_experimental@f3816a1
* Contributors: Levi Armstrong
